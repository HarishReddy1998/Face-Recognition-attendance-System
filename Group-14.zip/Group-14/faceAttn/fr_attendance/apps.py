from django.apps import AppConfig


class FrAttendanceConfig(AppConfig):
   
    name = "fr_attendance"
